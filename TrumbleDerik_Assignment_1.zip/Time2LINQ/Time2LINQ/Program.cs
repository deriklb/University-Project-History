﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary_1;
//using ClassLibrary_2;

namespace Time2LINQ
{
    class LINQ
    {
        static void Main(string[] args)
        {
            List<Time2> Tlist = new List<Time2>();

            List<Time2tz> Tlisttz = new List<Time2tz>();

            int hour = 0, minute = 0, second = 0;
            string tz = "CST";
            int ch;
            int report = 0;

            do
            {
                Console.WriteLine("Which type of object do you wish to enter?");
                Console.WriteLine("1 - Time2");
                Console.WriteLine("2 - Time2tz");
                Console.WriteLine("3 - Stop entering data");
                ch = System.Convert.ToInt32(Console.ReadLine());

                switch(ch)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter Hours:");
                            hour = System.Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Minutes:");
                            minute = System.Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Seconds:");
                            second = System.Convert.ToInt32(Console.ReadLine());
                            Time2 t2 = new Time2(hour, minute, second);
                            Tlist.Add(t2);
                            break;
                           
                        }

                    case 2:
                        {
                            Console.WriteLine("Enter Hours:");
                            hour = System.Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Minutes:");
                            minute = System.Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Seconds:");
                            second = System.Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter time zone:");
                            tz = Console.ReadLine();
                            Time2tz t2tz = new Time2tz(hour, minute, second, tz);
                            Tlisttz.Add(t2tz);
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Which report do you want?");
                            Console.WriteLine("1 - All objects");
                            Console.WriteLine("2 - All objects with AM times");
                            Console.WriteLine("3 - All objects with PM times");
                            Console.WriteLine("4 - QUIT");
                            report = System.Convert.ToInt32(Console.ReadLine());
                            var j =
                                from vari in Tlist
                                orderby vari.Hour
                                select vari;

                            var a =
                                from varitz in Tlisttz
                                orderby varitz.Hour
                                select varitz;

                            switch (report)
                            {
                                case 1:
                                    {

                                        foreach (var k in j)
                                        {
                                            Console.WriteLine(k.ToString());
                                        }

                                        foreach (var b in a)
                                        {
                                            Console.WriteLine(b.ToString());
                                        }
                                        break;
                                    }

                                case 2:
                                    {

                                        foreach (var k in j)
                                        {
                                            if (k.Hour < 12)
                                                Console.WriteLine(k.ToString());
                                            

                                        }

                                        foreach (var b in a)
                                        {
                                            if (b.Hour < 12)
                                                Console.WriteLine(b.ToString());
                                        }
                                        break;
                                    }


                                case 3:
                                    {

                                        foreach (var k in j)
                                        {
                                            if (k.Hour > 12)
                                                Console.WriteLine(k.ToString());


                                        }

                                        foreach (var b in a)
                                        {
                                            if (b.Hour > 12)
                                                Console.WriteLine(b.ToString());
                                        }
                                        break; 
                                    }



                                default:
                                    {
                                        //Console.WriteLine("wrong choice");
                                        break;
                                    }
                            }
                            break;
                        }

                    default:
                        {
                            //Console.WriteLine("Wrong input");
                            break;
                        }
                }
                
            }

            while (report != 4);

             
        }
    }
}
