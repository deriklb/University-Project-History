﻿using System;

namespace ClassLibrary_2
{
    public class Time2
    {

        private int hour;
        private int second;
        private int minute;
        private int totsec;
        


        //constructor ex 1
        public Time2(int hour = 0, int minute = 0, int second = 0)
        {

            SetTime(hour, minute, second);

        }


        //constructor ex 2
        public Time2(Time2 time)

           : this(time.Hour, time.Minute, time.Second) { }





       public void SetTime(int hour, int minute, int second)
        {

            totsec = hour * 60 * 60 + minute * 60 + second;

        }

/// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void addtime(int h, int m, int s)
        {
            Hour = Hour + h;
            Minute = Minute + m;
            Second = Second + s;

            Console.WriteLine($"new time value is {Hour:D2}:{Minute:D2}:{Second:D2}");

        }


        public void addtime(Time2 attime)
        {
            Hour = attime.Hour + Hour;
            Minute = attime.Minute + Minute;
            Second = attime.Second + Second;


            Console.WriteLine($"new time value is {Hour:D2}:{Minute:D2}:{Second:D2}");

        }

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public int Hour
        {
            get
            {
                return totsec/3600;
            }

            set
            {
               if (value <0 || value > 23)
               {
                   throw new ArgumentOutOfRangeException(nameof(value),
                   value, $"{nameof(Hour)} must be 0-23");
               }

                hour = value;
                
            }
        }










        public int Minute
        {
            get
            {
                return (totsec % 3600)/ 60;
                
            }

            set
           {
                if (value < 0 || value > 59 )
                {
                   throw new ArgumentOutOfRangeException(nameof(value),
                   value, $"{nameof(Minute)} must be 0-59");
                }

                minute = value;
                
            }
        }









        public int Second
        {
            get
            {
                return (totsec % 60);
            }

            set
            {
               if (value < 0 || value > 59)
                {
                 throw new ArgumentOutOfRangeException(nameof(value),
                   value, $"{nameof(Second)} must be 0-59");
                }

                second = value;
               
            }
        }




        public string ToUniversalString() =>
            $"{Hour:D2}:{Minute:D2}:{Second:D2}";


        public override string ToString() =>
            $"{((Hour == 0 || Hour == 12) ? 12 : Hour % 12)}:" + $"{Minute:D2}:{Second:D2} {(Hour < 12 ? "AM" : "PM")}";




    }
}