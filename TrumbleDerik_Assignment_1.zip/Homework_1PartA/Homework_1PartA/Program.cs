﻿using System;
using ClassLibrary_2;

public class Time2Test
{
    static void Main() {
        var t1 = new Time2(); // 00:00:00   
        var t2 = new Time2(2,00,00); // 02:00:00  
        var t3 = new Time2(9, 34); // 9:34:00   
        var t4 = new Time2(11, 25, 42); // 12:25:42 
        var t5 = new Time2(t4);// 12:25:42 

/////////////////////////////////////////////////////////part c/////////////////////////////////////////
        //var t8 = new Time2tz();
        //var t9 = new Time2tz(t8);
        //var t10 = new Time2tz(12,13,14,"MST");
        //var t11 = new Time2tz(t10);
////////////////////////////////////////////////////////////////////////////////////////////////////////

        Console.WriteLine("Constructed with:\n");
        Console.WriteLine("t1: all arguments defaulted");
        Console.WriteLine($"   {t1.ToUniversalString()}"); // 00:00:00 
        Console.WriteLine($"   {t1.ToString()}\n"); // 12:00:00 AM 
        Console.WriteLine( "t2: hour specified; minute and second defaulted");
        Console.WriteLine($"   {t2.ToUniversalString()}"); // 02:00:00 
        Console.WriteLine($"   {t2.ToString()}\n"); // 2:00:00 AM 
        Console.WriteLine( "t3: hour and minute specified; second defaulted");
        Console.WriteLine($"   {t3.ToUniversalString()}"); // 21:34:00 
        Console.WriteLine($"   {t3.ToString()}\n"); // 9:34:00 PM 
        Console.WriteLine("t4: hour, minute and second specified");
        Console.WriteLine($"   {t4.ToUniversalString()}"); // 12:25:42 
        Console.WriteLine($"   {t4.ToString()}\n"); // 12:25:42 PM 
        Console.WriteLine("t5: Time2 object t4 specified");
        Console.WriteLine($"   {t5.ToUniversalString()}"); // 12:25:
        Console.WriteLine($"   {t5.ToString()}"); // 12:25:42 PM 


////////////////////////////////////////////////////////////////////Part c//////////////////////////////////////////////////////////////////////////////
       /*
        
        Console.WriteLine("t8: ");
        Console.WriteLine($"   {t8.ToUniversalString()}"); // 12:25:
        Console.WriteLine($"   {t8.ToString()}"); // 12:25:42 PM
        Console.WriteLine("t9: Time2 object t4 specified");
        Console.WriteLine($"   {t9.ToUniversalString()}"); // 12:25:
        Console.WriteLine($"   {t9.ToString()}"); // 12:25:42 PM
        Console.WriteLine("t10: Time2 object t4 specified");
        Console.WriteLine($"   {t10.ToUniversalString()}"); // 12:25:
        Console.WriteLine($"   {t10.ToString()}"); // 12:25:42 PM

        */


        Console.WriteLine("t3: Time2 object t3 specified using addtime");
        try
        {
            t3.addtime(17, 1, 1);
        }
        catch (ArgumentOutOfRangeException ex)
        {
            Console.WriteLine("\nException while initializing t3: added too much time");
            Console.WriteLine(ex.Message);
        }



        Console.WriteLine("t3: Time2 object t3 specified using addtime constructor");
        try
        {
            t3.addtime(t2);
        }
        catch (ArgumentOutOfRangeException ex)
        {
            Console.WriteLine("\nException while initializing t3: added too much time");
            Console.WriteLine(ex.Message);
        }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        try
        {
            var t6 = new Time2(27, 74, 99); // invalid values

        }
        catch (ArgumentOutOfRangeException ex)
        {
            Console.WriteLine("\nException while initializing t6:");
            Console.WriteLine(ex.Message);
        }

        Console.ReadKey();

    }
}
